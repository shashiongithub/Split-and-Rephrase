for i in */*cleaned.xml ; do grep -c good $i ; done | awk 'BEGIN {total=0;}{total+=$1;}END {print "Total: ",total}'
